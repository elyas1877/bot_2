cd bot12 ;python3 __main__.py
